export default class Alumno {
    constructor(id, paterno, materno, nombre, fechaNacimiento, idCarrera) {
        this.id = id;
        this.paterno = paterno;
        this.materno = materno;
        this.nombre = nombre;
        this.fechaNacimiento = fechaNacimiento;
        this.idCarrera = idCarrera;
    }
}