export default class Carrera {
    constructor(id, nombre) {
        this.id = id;
        this.nombre = nombre;

    }
}